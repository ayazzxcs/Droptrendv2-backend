import puppeteer from "puppeteer-extra";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import { readJson, writeJson, sleep, num } from "./utils.js";
import { HttpsProxyAgent } from "https-proxy-agent";

puppeteer.use(StealthPlugin());

// Monthly sequential proxy-rotation engine + Puppeteer Amazon enrichment.
// Rule:
// - Dynamically fetch free Google-passed proxies from Geonode.
// - Validate proxies against Google before executing live requests.
// - Rotate proxy gracefully if 429, CAPTCHA, or connection failures occur.
// - Extract Amazon candidate links from raw HTML payload.
// - Scrape candidates with Puppeteer and choose the best valid match.
// - If no Amazon result/match for that product, move to next product.
// - Save whatever data is collected and continue.

const PRODUCTS_PATH = process.env.PRODUCTS_PATH || "products.json";
const AMAZON_PRODUCTS_PATH = process.env.AMAZON_PRODUCTS_PATH || "amazon-products.json";
const USAGE_PATH = process.env.LENS_USAGE_PATH || "lens-provider-usage.json";

const products = readJson(PRODUCTS_PATH, []);
const month = new Date().toISOString().slice(0, 7);

// Monthly cache behavior:
// - First run of a new month ignores old amazon-products.json and starts fresh.
// - Later runs in the same month reuse amazon-products.json and skip already fetched products.
// - Next month automatically starts fresh again.
const FORCE_REFRESH = /^(1|true|yes)$/i.test(String(process.env.RESET_AMAZON_CACHE || "false"));
const existingMeta = readJson("lens-amazon-meta.json", {});
const sameMonthCache = !FORCE_REFRESH && existingMeta?.month === month;
const existingAmazon = sameMonthCache ? readJson(AMAZON_PRODUCTS_PATH, []) : [];

if (FORCE_REFRESH) {
  console.log(`Forced Amazon monthly refresh enabled for ${month}. Existing Amazon data and current-month provider usage will be ignored.`);
} else if (sameMonthCache) {
  console.log(`Same month cache detected (${month}). Existing Amazon data will be skipped.`);
} else {
  console.log(`New month/cache reset detected (${month}). Starting Amazon data from scratch.`);
}

const usage = readJson(USAGE_PATH, {});
if (FORCE_REFRESH || existingMeta?.month !== month) usage[month] = {};
usage[month] ||= {};

const MAX_PRODUCTS = Number(process.env.MONTHLY_LENS_MAX_PRODUCTS || 1500);
const START_INDEX = Number(process.env.MONTHLY_LENS_START_INDEX || 0);
const DELAY_MS = Number(process.env.MONTHLY_LENS_DELAY_MS || 1200);
const AMAZON_DELAY_MS = Number(process.env.AMAZON_PAGE_DELAY_MS || 3500);
const MIN_TITLE_MATCH = Number(process.env.AMAZON_MIN_TITLE_MATCH || 15);
const AMAZON_CANDIDATE_LIMIT = Number(process.env.AMAZON_CANDIDATE_LIMIT || 8);
const AMAZON_PAGE_WAIT_MS = Number(process.env.AMAZON_PAGE_WAIT_MS || 12000);
const ACCEPT_PROVIDER_METADATA = !/^(0|false|no)$/i.test(String(process.env.AMAZON_ACCEPT_PROVIDER_METADATA || "true"));

// Local proxy cache to avoid over-fetching Geonode API within a single run
let cachedProxies = [];

/**
 * 1. DYNAMIC FETCHING
 * Fetches free proxies from Geonode configured explicitly for Google scraping.
 */
async function fetchGeonodeProxies() {
  if (cachedProxies.length > 5) return cachedProxies;
  
  console.log("Fetching new list of Google-passed proxies from Geonode...");
  const url = "https://proxylist.geonode.com/api/proxy-list?limit=100&page=1&sort_by=lastChecked&sort_type=desc&google=true";
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Geonode API error: \${response.status}`);
    const data = await response.json();
    
    if (!data.data || !Array.isArray(data.data)) return cachedProxies;
    
    const fetched = data.data.map(p => {
      const protocol = p.protocols.includes("https") ? "https" : "http";
      return `\${protocol}://\${p.ip}:\${p.port}`;
    });
    
    cachedProxies = [...new Set([...cachedProxies, ...fetched])];
    console.log(`Successfully buffered \${cachedProxies.length} total unique proxies.`);
    return cachedProxies;
  } catch (error) {
    console.error("Failed to fetch proxies from Geonode:", error.message);
    return cachedProxies;
  }
}

/**
 * 2. LIVE PROXY VALIDATION
 * Tests an individual proxy against google.com with a tight 3-second timeout.
 */
async function validateProxy(proxyUrl) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    const agent = new HttpsProxyAgent(proxyUrl);

    const response = await fetch("https://www.google.com", {
      signal: controller.signal,
      agent,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });
    
    clearTimeout(timeoutId);
    return response.ok;
  } catch {
    return false;
  }
}

function safeUrl(value) {
  try {
    const u = new URL(String(value || ""));
    return ["http:", "https:"].includes(u.protocol) ? u.toString() : "";
  } catch {
    return "";
  }
}

function productName(p) {
  return String(p.raw?.productNameEn || p.productNameEn || p.name || p.productName || "").trim();
}

function productImage(p) {
  const img =
    p.supplierImage ||
    p.productPageImage ||
    p.listingImage ||
    p.image ||
    p.productImage ||
    p.bigImage ||
    p.raw?.supplierImage ||
    p.raw?.productPageImage ||
    p.raw?.productImage ||
    p.raw?.bigImage ||
    p.raw?.image;

  return Array.isArray(img) ? safeUrl(img[0]) : safeUrl(img);
}

function normalizeText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const STOP = new Set([
  "the","and","for","with","from","new","hot","sale","best","top",
  "high","quality","product","products","dropshipping","wholesale","supplier"
]);

function tokens(text) {
  return normalizeText(text).split(/\s+/).filter(w => w.length > 2 && !STOP.has(w));
}

function titleSimilarity(a, b) {
  const aTokens = tokens(a);
  const bTokens = new Set(tokens(b));
  if (!aTokens.length || !bTokens.size) return 0;
  const hits = aTokens.filter(t => bTokens.has(t)).length;
  return Math.round(Math.min(100, (hits / aTokens.length) * 100));
}

function normalizeReviewCount(text) {
  if (!text) return 0;
  const cleaned = String(text).replace(/,/g, "");
  const m = cleaned.match(/(\d+(\.\d+)?)(k|m)?/i);
  if (!m) return 0;

  let value = Number(m[1]);
  const suffix = (m[3] || "").toLowerCase();
  if (suffix === "k") value *= 1000;
  if (suffix === "m") value *= 1000000;

  return Math.round(value);
}

function demandScore({ rating, ratingsTotal, isBestSeller, matchScore }) {
  const ratingScore = Math.min(35, Math.max(0, num(rating) * 7));
  const reviewScore = Math.min(45, Math.log10(num(ratingsTotal) + 1) * 11);
  const badgeScore = isBestSeller ? 10 : 0;
  const matchBonus = Math.min(10, Math.max(0, matchScore - 50) / 5);
  return Math.round(Math.min(100, ratingScore + reviewScore + badgeScore + matchBonus));
}

function isAmazonUrl(url) {
  try {
    return /(^|\.)amazon\./i.test(new URL(url).hostname);
  } catch {
    return false;
  }
}

// Ensure update/tracking metrics are correctly stored for tracking
function trackProxyUsage(proxy, status) {
  usage[month][proxy] ||= { attempts: 0, successes: 0, failures: 0 };
  usage[month][proxy].attempts += 1;
  if (status === "success") usage[month][proxy].successes += 1;
  else usage[month][proxy].failures += 1;
  writeJson(USAGE_PATH, usage);
}

function cleanAmazonUrl(url) {
  try {
    const u = new URL(url);
    return `\${u.origin}\${u.pathname}`;
  } catch {
    return url;
  }
}

function firstValue(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return "";
}

function numberFromAny(value) {
  if (value === undefined || value === null || value === "") return 0;
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const match = String(value).replace(/,/g, "").match(/(\d+(?:\.\d+)?)/);
  return match ? Number(match[1]) : 0;
}

function reviewCountFromAny(value) {
  if (value === undefined || value === null || value === "") return 0;
  if (typeof value === "number") return Math.max(0, Math.round(value));
  return normalizeReviewCount(String(value));
}

function asinFromUrl(url) {
  const match = String(url || "").match(/\/(?:dp|gp\/product|product)\/([A-Z0-9]{10})(?:[/?]|$)/i);
  return match ? match[1].toUpperCase() : "";
}

function mergeCandidate(existing, incoming) {
  if (!existing) return incoming;
  return {
    ...existing,
    ...incoming,
    title: incoming.title || existing.title || "",
    rating: num(incoming.rating) || num(existing.rating) || 0,
    ratingsTotal: num(incoming.ratingsTotal) || num(existing.ratingsTotal) || 0,
    badgeText: incoming.badgeText || existing.badgeText || "",
    image: incoming.image || existing.image || "",
    asin: incoming.asin || existing.asin || "",
    providerMetadata: {
      ...(existing.providerMetadata || {}),
      ...(incoming.providerMetadata || {})
    }
  };
}

function extractAmazonLinks(data) {
  const byUrl = new Map();

  function urlsInText(value) {
    const text = String(value || "")
      .replace(/&amp;/gi, "&")
      .replaceAll("\/", "/");

    const urls = new Set();
    const httpUrlPattern = new RegExp("https?://[^\\s\"'<>\\\\]+", "gi");
    for (const match of text.matchAll(httpUrlPattern)) {
      urls.add(match[0].replace(/[),.;]+$/, ""));
    }
    return [...urls];
  }

  function addCandidate(rawUrl, node = {}, inheritedTitle = "") {
    if (!rawUrl) return;

    let candidateUrl = rawUrl;
    try {
      const u = new URL(String(candidateUrl));
      const wrapped = u.searchParams.get("url") || u.searchParams.get("q");
      if (wrapped && /^https?:\/\//i.test(wrapped)) candidateUrl = wrapped;
    } catch {}

    if (!isAmazonUrl(candidateUrl)) return;

    const clean = cleanAmazonUrl(candidateUrl);
    const rich = node?.rich_snippet?.top?.detected_extensions ||
      node?.richSnippet?.top?.detectedExtensions ||
      node?.detected_extensions || {};

    const title = String(firstValue(
      node.title,
      node.name,
      node.product_title,
      node.productTitle,
      node.text,
      inheritedTitle
    ) || "").trim();

    const rating = numberFromAny(firstValue(
      node.rating,
      node.stars,
      node.rating_value,
      node.ratingValue,
      node.product_rating,
      node.productRating,
      rich.rating,
      rich.stars
    ));

    const ratingsTotal = reviewCountFromAny(firstValue(
      node.reviews,
      node.review_count,
      node.reviewCount,
      node.reviews_count,
      node.reviewsCount,
      node.rating_count,
      node.ratingCount,
      node.ratings,
      node.ratings_total,
      node.ratingsTotal,
      rich.reviews,
      rich.review_count,
      rich.ratings
    ));

    const badgeText = String(firstValue(
      node.badge,
      node.badgeText,
      node.tag,
      node.label
    ) || "").trim();

    const image = safeUrl(firstValue(
      node.thumbnail,
      node.image,
      node.image_url,
      node.imageUrl,
      node.product_image,
      node.productImage
    ));

    const candidate = {
      url: clean,
      title,
      rating,
      ratingsTotal,
      badgeText,
      image,
      asin: asinFromUrl(clean),
      providerMetadata: {
        rating,
        ratingsTotal,
        badgeText,
        title
      }
    };

    byUrl.set(clean, mergeCandidate(byUrl.get(clean), candidate));
  }

  function walk(node, inheritedTitle = "") {
    if (!node) return;

    if (typeof node === "string") {
      addCandidate(node, {}, inheritedTitle);
      for (const url of urlsInText(node)) {
        addCandidate(url, {}, inheritedTitle);
      }
      return;
    }

    if (Array.isArray(node)) {
      for (const item of node) walk(item, inheritedTitle);
      return;
    }

    if (typeof node === "object") {
      const possibleTitle = String(firstValue(
        node.title,
        node.name,
        node.product_title,
        node.productTitle,
        node.text,
        inheritedTitle
      ) || "");

      const possibleUrl = firstValue(
        node.link,
        node.url,
        node.source_url,
        node.result_url,
        node.sourceUrl,
        node.page_url,
        node.href,
        node.product_link,
        node.productLink
      );

      if (possibleUrl) addCandidate(possibleUrl, node, possibleTitle);

      for (const value of Object.values(node)) {
        walk(value, possibleTitle);
      }
    }
  }

  walk(data);
  return [...byUrl.values()];
}

/**
 * 3. AUTOMATED FAILOVER & ROTATION FOR GOOGLE LENS
 * Replaces direct third-party providers with direct, proxy-rotated Lens HTML scraping loop.
 */
async function findAmazonCandidatesByLens(imageUrl) {
  let lastQuotaError = "";
  let currentProxy = null;
  
  const targetLensUrl = `https://lens.google.com/v3/upload?url=\${encodeURIComponent(imageUrl)}`;
  const organicHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive"
  };

  while (true) {
    const pool = await fetchGeonodeProxies();
    if (pool.length === 0) {
      return { exhausted: true, provider: null, links: [], error: "No operational proxies left in the rotation sequence pool." };
    }

    currentProxy = pool.shift();
    console.log(`Verifying connection path for proxy node: \${currentProxy}`);
    
    const isLive = await validateProxy(currentProxy);
    if (!isLive) {
      console.log(`Proxy \${currentProxy} failed connectivity window. Discarding.`);
      continue;
    }

    try {
      console.log(`Executing direct Google Lens call over valid proxy terminal: \${currentProxy}`);
      const agent = new HttpsProxyAgent(currentProxy);
      
      const response = await fetch(targetLensUrl, { headers: organicHeaders, agent });
      const text = await response.text();

      if (response.status === 429) throw new Error("HTTP 429 Rate limiting payload matched.");
      if (/captcha|enter the characters you see below|verify you are human/i.test(text)) {
        throw new Error("Google Captcha/interstitial payload wall encountered.");
      }
      if (!response.ok) throw new Error(`HTTP Error Status Signature: \${response.status}`);

      // Successfully processed request! Convert HTML stream tokens to matches
      trackProxyUsage(currentProxy, "success");
      await sleep(DELAY_MS);
      
      const links = extractAmazonLinks(text);
      const amazon = links
        .filter(x => x?.url && isAmazonUrl(x.url))
        .slice(0, AMAZON_CANDIDATE_LIMIT);

      console.log(`Extracted \${links.length} visual matches from layout; parsing top \${amazon.length} Amazon products.`);
      return { exhausted: false, provider: `geonode_proxy_\${currentProxy}`, links: amazon };

    } catch (err) {
      const message = err.message || String(err);
      console.warn(`Proxy node failed processing sequence: \${message}. Retrying execution with next node.`);
      trackProxyUsage(currentProxy, "failure");
      lastQuotaError = message;
      await sleep(DELAY_MS);
    }
  }
}

function betterAmazonCandidate(candidate, best) {
  if (!best) return true;

  if (num(candidate.matchScore) !== num(best.matchScore)) {
    return num(candidate.matchScore) > num(best.matchScore);
  }

  if (num(candidate.score) !== num(best.score)) {
    return num(candidate.score) > num(best.score);
  }

  return num(candidate.ratingsTotal) > num(best.ratingsTotal);
}

function randomViewport() {
  const widths = [1280, 1365, 1440, 1536];
  const heights = [720, 768, 800, 864, 900];
  return {
    width: widths[Math.floor(Math.random() * widths.length)],
    height: heights[Math.floor(Math.random() * heights.length)]
  };
}

async function setupAmazonPage(page) {
  await page.setViewport(randomViewport());
  await page.setExtraHTTPHeaders({ "Accept-Language": "en-US,en;q=0.9" });

  await page.setRequestInterception(true);
  page.on("request", req => {
    const type = req.resourceType();
    if (["media", "font"].includes(type)) return req.abort();
    return req.continue();
  });
}

async function safeText(page, selector) {
  try {
    return await page.$eval(selector, el => (el.innerText || el.textContent || "").trim());
  } catch {
    return "";
  }
}

async function bodyText(page) {
  try {
    return await page.evaluate(() => document.body?.innerText || "");
  } catch {
    return "";
  }
}

async function safeAttr(page, selector, attr) {
  try {
    return await page.$eval(selector, (el, attrName) => el.getAttribute(attrName) || "", attr);
  } catch {
    return "";
  }
}

function extractReviewCountFromText(text) {
  const value = String(text || "");

  const patterns = [
    /(\d[\d,\.]*\s*[km]?)\s+(?:global\s+)?ratings?/i,
    /(\d[\d,\.]*\s*[km]?)\s+(?:customer\s+)?reviews?/i,
    /(\d[\d,\.]*\s*[km]?)\s+ratings?\s*\|/i,
    /ratings?\s*[:\-]?\s*(\d[\d,\.]*\s*[km]?)/i,
    /reviews?\s*[:\-]?\s*(\d[\d,\.]*\s*[km]?)/i
  ];

  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match) return normalizeReviewCount(match[1]);
  }

  return 0;
}

async function extractJsonLdProduct(page) {
  const rawScripts = await page.$$eval('script[type="application/ld+json"]', elements =>
    elements.map(element => element.textContent || "")
  ).catch(() => []);

  for (const raw of rawScripts) {
    try {
      const parsed = JSON.parse(raw);
      const product = parsed["@type"] === "Product" ? parsed : null; // simplified lookup matching original footprint
      if (!product) continue;

      const aggregate = product.aggregateRating || {};
      return {
        title: String(product.name || "").trim(),
        rating: numberFromAny(aggregate.ratingValue),
        ratingsTotal: reviewCountFromAny(
          aggregate.ratingCount || aggregate.reviewCount || product.reviewCount
        ),
        image: safeUrl(Array.isArray(product.image) ? product.image[0] : product.image),
        badgeText: ""
      };
    } catch {}
  }

  return { title: "", rating: 0, ratingsTotal: 0, image: "", badgeText: "" };
}

function extractEmbeddedAmazonData(html) {
  const source = String(html || "");

  const titlePatterns = [
    /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)/i,
    /<meta[^>]+name=["']title["'][^>]+content=["']([^"']+)/i,
    /"productTitle"\s*:\s*"([^"]+)"/i,
    /"title"\s*:\s*"([^"]{10,300})"/i
  ];

  const ratingPatterns = [
    /"averageStarRating"\s*:\s*([0-5](?:\.\d+)?)/i,
    /"ratingValue"\s*:\s*"?.([0-5](?:\.\d+)?)"?/i,
    /([0-5](?:\.\d+)?)\s+out of 5 stars/i
  ];

  const reviewPatterns = [
    /"ratingCount"\s*:\s*"?.([\d,.]+[km]?)"?/i,
    /"reviewCount"\s*:\s*"?.([\d,.]+[km]?)"?/i,
    /"totalReviewCount"\s*:\s*"?.([\d,.]+[km]?)"?/i,
    /([\d,.]+[km]?)\s+(?:global\s+)?ratings?/i
  ];

  let title = "";
  let rating = 0;
  let ratingsTotal = 0;

  for (const pattern of titlePatterns) {
    const match = source.match(pattern);
    if (match) {
      title = String(match[1] || "").replace(/\u0026/g, "&").replace(/&quot;/g, '"').trim();
      if (title) break;
    }
  }

  for (const pattern of ratingPatterns) {
    const match = source.match(pattern);
    if (match) {
      rating = numberFromAny(match[1]);
      if (rating) break;
    }
  }

  for (const pattern of reviewPatterns) {
    const match = source.match(pattern);
    if (match) {
      ratingsTotal = reviewCountFromAny(match[1]);
      if (ratingsTotal) break;
    }
  }

  return { title, rating, ratingsTotal };
}

async function scrapeAmazonWithPuppeteer(browser, candidate, cjName) {
  const amazonUrl = candidate.url;
  const page = await browser.newPage();
  await setupAmazonPage(page);

  try {
    const response = await page.goto(amazonUrl, { waitUntil: "domcontentloaded", timeout: 70000 });
    const status = response?.status?.() || 0;

    await Promise.race([
      page.waitForSelector("#productTitle, h1, script[type='application/ld+json']", { timeout: AMAZON_PAGE_WAIT_MS }),
      sleep(AMAZON_PAGE_WAIT_MS)
    ]).catch(() => {});

    await sleep(Math.min(5000, AMAZON_DELAY_MS) + Math.floor(Math.random() * 1800));

    let blockedError = null;
    try {
      await checkAmazonBlocked(page);
    } catch (err) {
      blockedError = err;
    }

    await humanPause(page);

    const jsonLd = await extractJsonLdProduct(page);
    const html = await page.content().catch(() => "");
    const embedded = extractEmbeddedAmazonData(html);

    const selectorTitle =
      await safeText(page, "#productTitle") ||
      await safeText(page, "h1 span") ||
      await safeText(page, "h1") ||
      await safeAttr(page, "meta[name='title']", "content") ||
      await safeAttr(page, "meta[property='og:title']", "content") ||
      await safeText(page, "title");

    const title = String(
      selectorTitle || jsonLd.title || embedded.title || candidate.title || ""
    ).trim();

    const ratingText =
      await safeText(page, "#acrPopover span.a-icon-alt") ||
      await safeText(page, "#acrPopover") ||
      await safeText(page, "span.a-icon-alt") ||
      await safeText(page, "[data-hook='rating-out-of-text']") ||
      await safeAttr(page, "meta[name='twitter:data1']", "content") ||
      await safeAttr(page, "meta[property='og:rating']", "content");

    const ratingMatch = ratingText.match(/(\d+(?:\.\d+)?)/);
    const selectorRating = ratingMatch ? Number(ratingMatch[1]) : 0;
    const rating = selectorRating || num(jsonLd.rating) || num(embedded.rating) || num(candidate.rating) || 0;

    const reviewsText =
      await safeText(page, "#acrCustomerReviewText") ||
      await safeText(page, "#acrCustomerReviewLink") ||
      await safeText(page, "[data-hook='total-review-count']") ||
      await safeText(page, "[data-hook='rating-count']") ||
      await safeText(page, "a[href*='customerReviews']") ||
      await safeText(page, "a[href*='product-reviews']");

    const pageText = await bodyText(page);
    const ratingsTotal =
      normalizeReviewCount(reviewsText) ||
      extractReviewCountFromText(pageText) ||
      num(jsonLd.ratingsTotal) ||
      num(embedded.ratingsTotal) ||
      num(candidate.ratingsTotal) ||
      0;

    const selectorBadge =
      await safeText(page, "#zeitgeistBadge_feature_div") ||
      await safeText(page, ".ac-badge-text-primary") ||
      await safeText(page, ".badge-wrapper") ||
      await safeText(page, "span:has-text('Best Seller')");

    const badgeText = selectorBadge || candidate.badgeText || "";
    const isBestSeller = /best seller|amazon'?s choice/i.test(badgeText);
    const matchScore = titleSimilarity(cjName, title);
    const score = demandScore({ rating, ratingsTotal, isBestSeller, matchScore });

    const sourceParts = [];
    if (selectorTitle || selectorRating || reviewsText) sourceParts.push("amazon-dom");
    if (jsonLd.title || jsonLd.rating || jsonLd.ratingsTotal) sourceParts.push("amazon-jsonld");
    if (embedded.title || embedded.rating || embedded.ratingsTotal) sourceParts.push("amazon-embedded");
    if (candidate.title || candidate.rating || candidate.ratingsTotal) sourceParts.push("lens-provider-metadata");

    console.log(
      `Amazon extracted data: status=\${status} finalUrl="\${page.url()}" title="\${title}" ` +
      `ratingText="\${ratingText}" reviewsText="\${reviewsText}" rating="\${rating}" reviews="\${ratingsTotal}" ` +
      `sources="\${sourceParts.join("+") || "none"}"\${blockedError ? ` blocked="\${blockedError.message}"` : ""}`
    );

    if (blockedError && !title && !rating && !ratingsTotal) throw blockedError;

    return {
      title,
      url: cleanAmazonUrl(page.url() || amazonUrl),
      asin: candidate.asin || asinFromUrl(page.url() || amazonUrl),
      rating: rating || "",
      ratingsTotal: ratingsTotal || 0,
      isBestSeller,
      badgeText,
      matchScore,
      score,
      source: sourceParts.join("+") || "amazon-page-no-structured-data",
      blocked: Boolean(blockedError),
      httpStatus: status,
      fetchedAt: new Date().toISOString()
    };
  } finally {
    await page.close().catch(() => {});
  }
}

function dataFromProviderCandidate(candidate, cjName) {
  if (!candidate) return null;

  const title = String(candidate.title || "").trim();
  const rating = num(candidate.rating);
  const ratingsTotal = num(candidate.ratingsTotal);
  const badgeText = String(candidate.badgeText || "").trim();
  const isBestSeller = /best seller|amazon'?s choice/i.test(badgeText);
  const matchScore = titleSimilarity(cjName, title);

  if (!title || (!rating && !ratingsTotal && !isBestSeller)) return null;

  return {
    title,
    url: cleanAmazonUrl(candidate.url),
    asin: candidate.asin || asinFromUrl(candidate.url),
    rating: rating || "",
    ratingsTotal: ratingsTotal || 0,
    isBestSeller,
    badgeText,
    matchScore,
    score: demandScore({ rating, ratingsTotal, isBestSeller, matchScore }),
    source: "lens-provider-metadata",
    fetchedAt: new Date().toISOString()
  };
}

async function checkAmazonBlocked(page) {
  const text = await bodyText(page);
  const html = await page.content().catch(() => "");
  const combined = `\${text}\n\${html}`;

  if (/captcha|enter the characters you see below|sorry, we just need to make sure|verify you are human/i.test(combined)) {
    throw new Error("Amazon CAPTCHA/bot check detected");
  }
  if (/automated access|api-services-support@amazon|robot check|dogs of amazon|sorry! something went wrong|page not found/i.test(combined)) {
    throw new Error("Amazon interstitial or blocked page detected");
  }
}

async function humanPause(page) {
  try {
    await sleep(1000 + Math.floor(Math.random() * 2200));
    await page.mouse.move(
      200 + Math.floor(Math.random() * 700),
      150 + Math.floor(Math.random() * 450),
      { steps: 8 + Math.floor(Math.random() * 10) }
    );
    await page.evaluate(() => window.scrollBy(0, Math.floor(150 + Math.random() * 500)));
    await sleep(800 + Math.floor(Math.random() * 1600));
  } catch {}
}

function alreadyHasAmazon(product) {
  const pid = String(product.id || "");
  const name = productName(product).toLowerCase();

  return existingAmazon.some(a => {
    const aid = String(a.productId || "");
    const aname = String(a.productName || "").toLowerCase();
    return (pid && aid && pid === aid) || (name && aname && name === aname);
  });
}

// Global initialization sequence
const browser = await puppeteer.launch({
  headless: "new",
  args: [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-setuid-sandbox"
  ]
});

const matches = [];
const failures = [];
const amazonSignals = [...existingAmazon];
const endIndex = Math.min(products.length, START_INDEX + MAX_PRODUCTS);

// Initial initialization of proxy storage configurations
await fetchGeonodeProxies();

for (let i = START_INDEX; i < endIndex; i++) {
  const p = products[i];
  const name = productName(p);
  const image = productImage(p);

  if (!name || !image) {
    failures.push({ index: i, name, reason: "missing product name or image" });
    continue;
  }

  if (alreadyHasAmazon(p)) {
    console.log(`Skip existing Amazon data: \${name}`);
    continue;
  }

  try {
    console.log(`Monthly Lens \${i + 1}/\${products.length}: \${name}`);
    const found = await findAmazonCandidatesByLens(image);

    if (found.exhausted) {
      console.log("All validated proxies from Geonode failed or exhausted. Halting process.");
      break;
    }

    if (!found.links.length) {
      console.log(`No Amazon match via proxy loop routing: \${name}`);
      failures.push({
        index: i,
        name,
        image,
        provider: found.provider,
        reason: found.error || "no amazon links found from direct html payload matching layout tokens"
      });
      continue;
    }

    let data = null;
    const candidateFailures = [];

    console.log(`Checking \${found.links.length} Amazon candidates via Puppeteer for: \${name}`);

    for (let c = 0; c < found.links.length; c++) {
      const candidate = found.links[c];
      console.log(`Amazon candidate \${c + 1}/\${found.links.length} via \${found.provider}: \${candidate.url}`);
      let candidateData = null;

      try {
        candidateData = await scrapeAmazonWithPuppeteer(browser, candidate, name);
      } catch (err) {
        console.log(`Amazon page extraction failed for candidate \${c + 1}/\${found.links.length}: \${err.message}`);

        if (ACCEPT_PROVIDER_METADATA) {
          candidateData = dataFromProviderCandidate(candidate, name);
          if (candidateData) {
            console.log(
              `Using proxy payload snapshot fallback for candidate \${c + 1}: ` +
              `title="\${candidateData.title}" rating="\${candidateData.rating}" reviews="\${candidateData.ratingsTotal}"`
            );
          }
        }

        if (!candidateData) {
          candidateFailures.push({
            candidate: c + 1,
            amazonUrl: candidate.url,
            reason: `amazon page extraction failed: \${err.message}`
          });
          continue;
        }
      }

      candidateData.candidatePosition = c + 1;

      if (!candidateData.title || (!candidateData.rating && !candidateData.ratingsTotal && !candidateData.isBestSeller)) {
        candidateFailures.push({
          candidate: c + 1,
          amazonUrl: candidate.url,
          title: candidateData.title,
          reason: "amazon candidate missing structural layout details"
        });
        continue;
      }

      if (candidateData.matchScore < MIN_TITLE_MATCH) {
        candidateFailures.push({
          candidate: c + 1,
          amazonUrl: candidate.url,
          title: candidateData.title,
          matchScore: candidateData.matchScore,
          reason: `weak title match score threshold: \${candidateData.matchScore}`
        });
        continue;
      }

      if (betterAmazonCandidate(candidateData, data)) {
        data = candidateData;
      }
    }

    if (!data) {
      failures.push({
        index: i,
        name,
        image,
        provider: found.provider,
        reason: "no valid amazon candidate matched structural thresholds after puppeteer deep check evaluation"
      });
      continue;
    }

    const signal = {
      productId: p.id,
      keyword: p.id || name,
      productName: name,
      image,
      title: data.title,
      asin: data.asin || asinFromUrl(data.url),
      score: data.score,
      bestRating: data.rating,
      bestRatingsTotal: data.ratingsTotal,
      bestPrice: "",
      position: data.candidatePosition || 1,
      amazonCandidatesChecked: found.links.length,
      isBestSeller: data.isBestSeller,
      badgeText: data.badgeText,
      productUrl: data.url,
      matchScore: data.matchScore,
      matchType: "image",
      lensProvider: found.provider,
      source: data.source,
      fetchedAt: data.fetchedAt
    };

    amazonSignals.push(signal);
    matches.push({
      productId: p.id,
      productName: name,
      productImage: image,
      provider: found.provider,
      amazon: data
    });

    if (matches.length % 10 === 0) {
      writeJson(AMAZON_PRODUCTS_PATH, amazonSignals);
      writeJson("lens-amazon-matches.json", matches);
      writeJson("lens-amazon-failures.json", failures);
      writeJson(USAGE_PATH, usage);
    }

    await sleep(AMAZON_DELAY_MS + Math.floor(Math.random() * 2000));
  } catch (err) {
    failures.push({ index: i, name, image, reason: err.message });
  }
}

await browser.close().catch(() => {});

writeJson(AMAZON_PRODUCTS_PATH, amazonSignals);
writeJson("lens-amazon-matches.json", matches);
writeJson("lens-amazon-failures.json", failures);
writeJson(USAGE_PATH, usage);
writeJson("lens-amazon-meta.json", {
  updatedAt: new Date().toISOString(),
  month,
  mode: "Geonode dynamic proxy terminal rotation + Puppeteer Amazon extraction matrix",
  startIndex: START_INDEX,
  maxProducts: MAX_PRODUCTS,
  matches: matches.length,
  failures: failures.length
});

console.log(`Execution parsing run completed. Matches recorded: \${matches.length}, failures: \${failures.length}`);
